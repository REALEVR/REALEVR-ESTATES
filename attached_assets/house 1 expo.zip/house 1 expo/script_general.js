(function(){
var translateObjs = {};
function trans(a, b) {
    var c = arguments['length'] === 0x1 ? [arguments[0x0]] : Array['apply'](null, arguments);
    return translateObjs[c[0x0]] = c, '';
}
function regTextVar(a, b) {
    var c = ![];
    return d(b);
    function d(k, l) {
        switch (k['toLowerCase']()) {
        case 'title':
        case 'subtitle':
        case 'photo.title':
        case 'photo.description':
            var m = (function () {
                switch (k['toLowerCase']()) {
                case 'title':
                case 'photo.title':
                    return 'media.label';
                case 'subtitle':
                    return 'media.data.subtitle';
                case 'photo.description':
                    return 'media.data.description';
                }
            }());
            if (m)
                return function () {
                    var r, s, t = (l && l['viewerName'] ? this['getComponentByName'](l['viewerName']) : undefined) || this['getMainViewer']();
                    if (k['toLowerCase']()['startsWith']('photo'))
                        r = this['getByClassName']('PhotoAlbumPlayListItem')['filter'](function (v) {
                            var w = v['get']('player');
                            return w && w['get']('viewerArea') == t;
                        })['map'](function (v) {
                            return v['get']('media')['get']('playList');
                        });
                    else
                        r = this['_getPlayListsWithViewer'](t), s = j['bind'](this, t);
                    if (!c) {
                        for (var u = 0x0; u < r['length']; ++u) {
                            r[u]['bind']('changing', f, this);
                        }
                        c = !![];
                    }
                    return i['call'](this, r, m, s);
                };
            break;
        case 'tour.name':
        case 'tour.description':
            return function () {
                return this['get']('data')['tour']['locManager']['trans'](k);
            };
        default:
            if (k['toLowerCase']()['startsWith']('viewer.')) {
                var n = k['split']('.'), o = n[0x1];
                if (o) {
                    var p = n['slice'](0x2)['join']('.');
                    return d(p, { 'viewerName': o });
                }
            } else {
                if (k['toLowerCase']()['startsWith']('quiz.') && 'Quiz' in TDV) {
                    var q = undefined, m = (function () {
                            switch (k['toLowerCase']()) {
                            case 'quiz.questions.answered':
                                return TDV['Quiz']['PROPERTY']['QUESTIONS_ANSWERED'];
                            case 'quiz.question.count':
                                return TDV['Quiz']['PROPERTY']['QUESTION_COUNT'];
                            case 'quiz.items.found':
                                return TDV['Quiz']['PROPERTY']['ITEMS_FOUND'];
                            case 'quiz.item.count':
                                return TDV['Quiz']['PROPERTY']['ITEM_COUNT'];
                            case 'quiz.score':
                                return TDV['Quiz']['PROPERTY']['SCORE'];
                            case 'quiz.score.total':
                                return TDV['Quiz']['PROPERTY']['TOTAL_SCORE'];
                            case 'quiz.time.remaining':
                                return TDV['Quiz']['PROPERTY']['REMAINING_TIME'];
                            case 'quiz.time.elapsed':
                                return TDV['Quiz']['PROPERTY']['ELAPSED_TIME'];
                            case 'quiz.time.limit':
                                return TDV['Quiz']['PROPERTY']['TIME_LIMIT'];
                            case 'quiz.media.items.found':
                                return TDV['Quiz']['PROPERTY']['PANORAMA_ITEMS_FOUND'];
                            case 'quiz.media.item.count':
                                return TDV['Quiz']['PROPERTY']['PANORAMA_ITEM_COUNT'];
                            case 'quiz.media.questions.answered':
                                return TDV['Quiz']['PROPERTY']['PANORAMA_QUESTIONS_ANSWERED'];
                            case 'quiz.media.question.count':
                                return TDV['Quiz']['PROPERTY']['PANORAMA_QUESTION_COUNT'];
                            case 'quiz.media.score':
                                return TDV['Quiz']['PROPERTY']['PANORAMA_SCORE'];
                            case 'quiz.media.score.total':
                                return TDV['Quiz']['PROPERTY']['PANORAMA_TOTAL_SCORE'];
                            case 'quiz.media.index':
                                return TDV['Quiz']['PROPERTY']['PANORAMA_INDEX'];
                            case 'quiz.media.count':
                                return TDV['Quiz']['PROPERTY']['PANORAMA_COUNT'];
                            case 'quiz.media.visited':
                                return TDV['Quiz']['PROPERTY']['PANORAMA_VISITED_COUNT'];
                            default:
                                var s = /quiz\.([\w_]+)\.(.+)/['exec'](k);
                                if (s) {
                                    q = s[0x1];
                                    switch ('quiz.' + s[0x2]) {
                                    case 'quiz.score':
                                        return TDV['Quiz']['OBJECTIVE_PROPERTY']['SCORE'];
                                    case 'quiz.score.total':
                                        return TDV['Quiz']['OBJECTIVE_PROPERTY']['TOTAL_SCORE'];
                                    case 'quiz.media.items.found':
                                        return TDV['Quiz']['OBJECTIVE_PROPERTY']['PANORAMA_ITEMS_FOUND'];
                                    case 'quiz.media.item.count':
                                        return TDV['Quiz']['OBJECTIVE_PROPERTY']['PANORAMA_ITEM_COUNT'];
                                    case 'quiz.media.questions.answered':
                                        return TDV['Quiz']['OBJECTIVE_PROPERTY']['PANORAMA_QUESTIONS_ANSWERED'];
                                    case 'quiz.media.question.count':
                                        return TDV['Quiz']['OBJECTIVE_PROPERTY']['PANORAMA_QUESTION_COUNT'];
                                    case 'quiz.questions.answered':
                                        return TDV['Quiz']['OBJECTIVE_PROPERTY']['QUESTIONS_ANSWERED'];
                                    case 'quiz.question.count':
                                        return TDV['Quiz']['OBJECTIVE_PROPERTY']['QUESTION_COUNT'];
                                    case 'quiz.items.found':
                                        return TDV['Quiz']['OBJECTIVE_PROPERTY']['ITEMS_FOUND'];
                                    case 'quiz.item.count':
                                        return TDV['Quiz']['OBJECTIVE_PROPERTY']['ITEM_COUNT'];
                                    case 'quiz.media.score':
                                        return TDV['Quiz']['OBJECTIVE_PROPERTY']['PANORAMA_SCORE'];
                                    case 'quiz.media.score.total':
                                        return TDV['Quiz']['OBJECTIVE_PROPERTY']['PANORAMA_TOTAL_SCORE'];
                                    }
                                }
                            }
                        }());
                    if (m)
                        return function () {
                            var r = this['get']('data')['quiz'];
                            if (r) {
                                if (!c) {
                                    if (q != undefined) {
                                        if (q == 'global') {
                                            var s = this['get']('data')['quizConfig'], t = s['objectives'];
                                            for (var u = 0x0, v = t['length']; u < v; ++u) {
                                                r['bind'](TDV['Quiz']['EVENT_OBJECTIVE_PROPERTIES_CHANGE'], h['call'](this, t[u]['id'], m), this);
                                            }
                                        } else
                                            r['bind'](TDV['Quiz']['EVENT_OBJECTIVE_PROPERTIES_CHANGE'], h['call'](this, q, m), this);
                                    } else
                                        r['bind'](TDV['Quiz']['EVENT_PROPERTIES_CHANGE'], g['call'](this, m), this);
                                    c = !![];
                                }
                                try {
                                    var w = 0x0;
                                    if (q != undefined) {
                                        if (q == 'global') {
                                            var s = this['get']('data')['quizConfig'], t = s['objectives'];
                                            for (var u = 0x0, v = t['length']; u < v; ++u) {
                                                w += r['getObjective'](t[u]['id'], m);
                                            }
                                        } else
                                            w = r['getObjective'](q, m);
                                    } else {
                                        w = r['get'](m);
                                        if (m == TDV['Quiz']['PROPERTY']['PANORAMA_INDEX'])
                                            w += 0x1;
                                    }
                                    return w;
                                } catch (x) {
                                    return undefined;
                                }
                            }
                        };
                }
            }
            break;
        }
        return function () {
            return '';
        };
    }
    function e() {
        var k = this['get']('data');
        k['updateText'](k['translateObjs'][a]);
    }
    function f(k) {
        var l = k['data']['nextSelectedIndex'];
        if (l >= 0x0) {
            var m = k['source']['get']('items')[l], n = function () {
                    m['unbind']('begin', n, this), e['call'](this);
                };
            m['bind']('begin', n, this);
        }
    }
    function g(k) {
        return function (l) {
            k in l && e['call'](this);
        }['bind'](this);
    }
    function h(k, l) {
        return function (m, n) {
            k == m && l in n && e['call'](this);
        }['bind'](this);
    }
    function i(k, l, m) {
        for (var n = 0x0; n < k['length']; ++n) {
            var o = k[n], p = o['get']('selectedIndex');
            if (p >= 0x0) {
                var q = l['split']('.'), r = o['get']('items')[p];
                if (m !== undefined && !m['call'](this, r))
                    continue;
                for (var s = 0x0; s < q['length']; ++s) {
                    if (r == undefined)
                        return '';
                    r = 'get' in r ? r['get'](q[s]) : r[q[s]];
                }
                return r;
            }
        }
        return '';
    }
    function j(k, l) {
        var m = l['get']('player');
        return m !== undefined && m['get']('viewerArea') == k;
    }
}
var script = {"downloadEnabled":true,"layout":"absolute","scripts":{"getMediaHeight":TDV.Tour.Script.getMediaHeight,"setPlayListSelectedIndex":TDV.Tour.Script.setPlayListSelectedIndex,"showPopupImage":TDV.Tour.Script.showPopupImage,"getGlobalAudio":TDV.Tour.Script.getGlobalAudio,"getMainViewer":TDV.Tour.Script.getMainViewer,"keepCompVisible":TDV.Tour.Script.keepCompVisible,"registerKey":TDV.Tour.Script.registerKey,"getComponentByName":TDV.Tour.Script.getComponentByName,"getPlayListsWithMedia":TDV.Tour.Script.getPlayListsWithMedia,"getMediaByName":TDV.Tour.Script.getMediaByName,"getQuizTotalObjectiveProperty":TDV.Tour.Script.getQuizTotalObjectiveProperty,"getPlayListItemIndexByMedia":TDV.Tour.Script.getPlayListItemIndexByMedia,"setMainMediaByIndex":TDV.Tour.Script.setMainMediaByIndex,"_initItemWithComps":TDV.Tour.Script._initItemWithComps,"syncPlaylists":TDV.Tour.Script.syncPlaylists,"getRootOverlay":TDV.Tour.Script.getRootOverlay,"initAnalytics":TDV.Tour.Script.initAnalytics,"showPopupPanoramaOverlay":TDV.Tour.Script.showPopupPanoramaOverlay,"executeFunctionWhenChange":TDV.Tour.Script.executeFunctionWhenChange,"copyObjRecursively":TDV.Tour.Script.copyObjRecursively,"setMainMediaByName":TDV.Tour.Script.setMainMediaByName,"_initTTSTooltips":TDV.Tour.Script._initTTSTooltips,"showWindow":TDV.Tour.Script.showWindow,"initOverlayGroupRotationOnClick":TDV.Tour.Script.initOverlayGroupRotationOnClick,"setMediaBehaviour":TDV.Tour.Script.setMediaBehaviour,"mixObject":TDV.Tour.Script.mixObject,"textToSpeech":TDV.Tour.Script.textToSpeech,"unregisterKey":TDV.Tour.Script.unregisterKey,"startModel3DWithCameraSpot":TDV.Tour.Script.startModel3DWithCameraSpot,"quizFinish":TDV.Tour.Script.quizFinish,"loadFromCurrentMediaPlayList":TDV.Tour.Script.loadFromCurrentMediaPlayList,"getPixels":TDV.Tour.Script.getPixels,"getModel3DInnerObject":TDV.Tour.Script.getModel3DInnerObject,"openLink":TDV.Tour.Script.openLink,"quizStart":TDV.Tour.Script.quizStart,"getMediaByTags":TDV.Tour.Script.getMediaByTags,"setSurfaceSelectionHotspotMode":TDV.Tour.Script.setSurfaceSelectionHotspotMode,"quizPauseTimer":TDV.Tour.Script.quizPauseTimer,"quizShowTimeout":TDV.Tour.Script.quizShowTimeout,"initQuiz":TDV.Tour.Script.initQuiz,"showPopupPanoramaVideoOverlay":TDV.Tour.Script.showPopupPanoramaVideoOverlay,"quizResumeTimer":TDV.Tour.Script.quizResumeTimer,"getActiveMediaWithViewer":TDV.Tour.Script.getActiveMediaWithViewer,"_getPlayListsWithViewer":TDV.Tour.Script._getPlayListsWithViewer,"setModel3DCameraSpot":TDV.Tour.Script.setModel3DCameraSpot,"setValue":TDV.Tour.Script.setValue,"existsKey":TDV.Tour.Script.existsKey,"setModel3DCameraSequence":TDV.Tour.Script.setModel3DCameraSequence,"getStateTextToSpeech":TDV.Tour.Script.getStateTextToSpeech,"getPlayListWithItem":TDV.Tour.Script.getPlayListWithItem,"_getObjectsByTags":TDV.Tour.Script._getObjectsByTags,"textToSpeechComponent":TDV.Tour.Script.textToSpeechComponent,"startPanoramaWithCamera":TDV.Tour.Script.startPanoramaWithCamera,"startPanoramaWithModel":TDV.Tour.Script.startPanoramaWithModel,"setObjectsVisibility":TDV.Tour.Script.setObjectsVisibility,"getActivePlayerWithViewer":TDV.Tour.Script.getActivePlayerWithViewer,"copyToClipboard":TDV.Tour.Script.copyToClipboard,"quizShowScore":TDV.Tour.Script.quizShowScore,"restartTourWithoutInteraction":TDV.Tour.Script.restartTourWithoutInteraction,"autotriggerAtStart":TDV.Tour.Script.autotriggerAtStart,"setStartTimeVideo":TDV.Tour.Script.setStartTimeVideo,"startMeasurement":TDV.Tour.Script.startMeasurement,"getKey":TDV.Tour.Script.getKey,"setObjectsVisibilityByID":TDV.Tour.Script.setObjectsVisibilityByID,"getComponentsByTags":TDV.Tour.Script.getComponentsByTags,"init":TDV.Tour.Script.init,"getOverlays":TDV.Tour.Script.getOverlays,"resumeGlobalAudios":TDV.Tour.Script.resumeGlobalAudios,"stopMeasurement":TDV.Tour.Script.stopMeasurement,"historyGoBack":TDV.Tour.Script.historyGoBack,"stopGlobalAudios":TDV.Tour.Script.stopGlobalAudios,"resumePlayers":TDV.Tour.Script.resumePlayers,"triggerOverlay":TDV.Tour.Script.triggerOverlay,"setObjectsVisibilityByTags":TDV.Tour.Script.setObjectsVisibilityByTags,"setOverlayBehaviour":TDV.Tour.Script.setOverlayBehaviour,"openEmbeddedPDF":TDV.Tour.Script.openEmbeddedPDF,"toggleTextToSpeechComponent":TDV.Tour.Script.toggleTextToSpeechComponent,"pauseCurrentPlayers":TDV.Tour.Script.pauseCurrentPlayers,"_initSplitViewer":TDV.Tour.Script._initSplitViewer,"toggleMeasurement":TDV.Tour.Script.toggleMeasurement,"changeBackgroundWhilePlay":TDV.Tour.Script.changeBackgroundWhilePlay,"stopGlobalAudio":TDV.Tour.Script.stopGlobalAudio,"getOverlaysByTags":TDV.Tour.Script.getOverlaysByTags,"getFirstPlayListWithMedia":TDV.Tour.Script.getFirstPlayListWithMedia,"changeOpacityWhilePlay":TDV.Tour.Script.changeOpacityWhilePlay,"getActivePlayersWithViewer":TDV.Tour.Script.getActivePlayersWithViewer,"getAudioByTags":TDV.Tour.Script.getAudioByTags,"setStartTimeVideoSync":TDV.Tour.Script.setStartTimeVideoSync,"skip3DTransitionOnce":TDV.Tour.Script.skip3DTransitionOnce,"pauseGlobalAudiosWhilePlayItem":TDV.Tour.Script.pauseGlobalAudiosWhilePlayItem,"changePlayListWithSameSpot":TDV.Tour.Script.changePlayListWithSameSpot,"sendAnalyticsData":TDV.Tour.Script.sendAnalyticsData,"updateDeepLink":TDV.Tour.Script.updateDeepLink,"updateMediaLabelFromPlayList":TDV.Tour.Script.updateMediaLabelFromPlayList,"cleanAllMeasurements":TDV.Tour.Script.cleanAllMeasurements,"pauseGlobalAudio":TDV.Tour.Script.pauseGlobalAudio,"updateIndexGlobalZoomImage":TDV.Tour.Script.updateIndexGlobalZoomImage,"setOverlaysVisibilityByTags":TDV.Tour.Script.setOverlaysVisibilityByTags,"stopTextToSpeech":TDV.Tour.Script.stopTextToSpeech,"setOverlaysVisibility":TDV.Tour.Script.setOverlaysVisibility,"cleanSelectedMeasurements":TDV.Tour.Script.cleanSelectedMeasurements,"pauseGlobalAudios":TDV.Tour.Script.pauseGlobalAudios,"setCameraSameSpotAsMedia":TDV.Tour.Script.setCameraSameSpotAsMedia,"historyGoForward":TDV.Tour.Script.historyGoForward,"_initTwinsViewer":TDV.Tour.Script._initTwinsViewer,"setMeasurementsVisibility":TDV.Tour.Script.setMeasurementsVisibility,"getOverlaysByGroupname":TDV.Tour.Script.getOverlaysByGroupname,"updateVideoCues":TDV.Tour.Script.updateVideoCues,"cloneBindings":TDV.Tour.Script.cloneBindings,"clonePanoramaCamera":TDV.Tour.Script.clonePanoramaCamera,"setComponentsVisibilityByTags":TDV.Tour.Script.setComponentsVisibilityByTags,"getMediaFromPlayer":TDV.Tour.Script.getMediaFromPlayer,"htmlToPlainText":TDV.Tour.Script.htmlToPlainText,"isCardboardViewMode":TDV.Tour.Script.isCardboardViewMode,"getCurrentPlayerWithMedia":TDV.Tour.Script.getCurrentPlayerWithMedia,"clone":TDV.Tour.Script.clone,"playGlobalAudioWhilePlay":TDV.Tour.Script.playGlobalAudioWhilePlay,"showComponentsWhileMouseOver":TDV.Tour.Script.showComponentsWhileMouseOver,"shareSocial":TDV.Tour.Script.shareSocial,"setDirectionalPanoramaAudio":TDV.Tour.Script.setDirectionalPanoramaAudio,"playGlobalAudio":TDV.Tour.Script.playGlobalAudio,"createTween":TDV.Tour.Script.createTween,"playGlobalAudioWhilePlayActiveMedia":TDV.Tour.Script.playGlobalAudioWhilePlayActiveMedia,"toggleMeasurementsVisibility":TDV.Tour.Script.toggleMeasurementsVisibility,"visibleComponentsIfPlayerFlagEnabled":TDV.Tour.Script.visibleComponentsIfPlayerFlagEnabled,"getMediaWidth":TDV.Tour.Script.getMediaWidth,"getPlayListItems":TDV.Tour.Script.getPlayListItems,"takeScreenshot":TDV.Tour.Script.takeScreenshot,"disableVR":TDV.Tour.Script.disableVR,"setPanoramaCameraWithCurrentSpot":TDV.Tour.Script.setPanoramaCameraWithCurrentSpot,"playAudioList":TDV.Tour.Script.playAudioList,"isPanorama":TDV.Tour.Script.isPanorama,"getCurrentPlayers":TDV.Tour.Script.getCurrentPlayers,"getPlayListItemByMedia":TDV.Tour.Script.getPlayListItemByMedia,"downloadFile":TDV.Tour.Script.downloadFile,"setPanoramaCameraWithSpot":TDV.Tour.Script.setPanoramaCameraWithSpot,"fixTogglePlayPauseButton":TDV.Tour.Script.fixTogglePlayPauseButton,"getPanoramaOverlayByName":TDV.Tour.Script.getPanoramaOverlayByName,"getPanoramaOverlaysByTags":TDV.Tour.Script.getPanoramaOverlaysByTags,"translate":TDV.Tour.Script.translate,"setMeasurementUnits":TDV.Tour.Script.setMeasurementUnits,"showPopupMedia":TDV.Tour.Script.showPopupMedia,"quizSetItemFound":TDV.Tour.Script.quizSetItemFound,"setComponentVisibility":TDV.Tour.Script.setComponentVisibility,"enableVR":TDV.Tour.Script.enableVR,"executeAudioActionByTags":TDV.Tour.Script.executeAudioActionByTags,"executeAudioAction":TDV.Tour.Script.executeAudioAction,"toggleVR":TDV.Tour.Script.toggleVR,"setEndToItemIndex":TDV.Tour.Script.setEndToItemIndex,"stopAndGoCamera":TDV.Tour.Script.stopAndGoCamera,"setMapLocation":TDV.Tour.Script.setMapLocation,"assignObjRecursively":TDV.Tour.Script.assignObjRecursively,"setLocale":TDV.Tour.Script.setLocale,"quizShowQuestion":TDV.Tour.Script.quizShowQuestion,"executeJS":TDV.Tour.Script.executeJS},"gap":10,"id":"rootPlayer","scrollBarMargin":2,"data":{"defaultLocale":"en","history":{},"textToSpeechConfig":{"pitch":1,"stopBackgroundAudio":false,"speechOnQuizQuestion":false,"volume":1,"speechOnInfoWindow":false,"speechOnTooltip":false,"rate":1},"displayTooltipInTouchScreens":true,"locales":{"en":"locale/en.txt"},"name":"Player4505"},"backgroundColor":["#FFFFFF"],"start":"this.init()","defaultMenu":["fullscreen","mute","rotation"],"scrollBarColor":"#000000","watermark":false,"children":["this.MainViewer"],"propagateClick":false,"backgroundColorRatios":[0],"class":"Player","minHeight":0,"minWidth":0,"height":"100%","hash": "d57f1a1f7f293e50f53f44edb8ddcaa1083c6c01b7fdca208bb9072fe0a47fee", "definitions": [{"adjacentPanoramas":[{"data":{"overlayID":"overlay_5F79FC17_4D39_CC33_41CA_341324142692"},"panorama":"this.panorama_434A5970_4D39_340D_41AB_0994DDE984F4","distance":10.14,"backwardYaw":-30.64,"yaw":51.81,"class":"AdjacentPanorama","select":"this.overlay_5F79FC17_4D39_CC33_41CA_341324142692.get('areas').forEach(function(a){ a.trigger('click') })"},{"data":{"overlayID":"overlay_5F5D0BA1_4D39_540F_41AF_3E38294A3AC6"},"panorama":"this.panorama_407FE2E8_4D39_741D_41B2_FCDF6042BAD4","distance":9.11,"backwardYaw":26.15,"yaw":115.63,"class":"AdjacentPanorama","select":"this.overlay_5F5D0BA1_4D39_540F_41AF_3E38294A3AC6.get('areas').forEach(function(a){ a.trigger('click') })"}],"frames":[{"class":"CubicPanoramaFrame","thumbnailUrl":"media/panorama_406B0668_4D39_5C1D_41BB_704D9F23A200_t.webp","cube":{"class":"ImageResource","levels":[{"height":2048,"rowCount":4,"url":"media/panorama_406B0668_4D39_5C1D_41BB_704D9F23A200_0/{face}/0/{row}_{column}.webp","colCount":24,"class":"TiledImageResourceLevel","tags":"ondemand","width":12288},{"height":1024,"rowCount":2,"url":"media/panorama_406B0668_4D39_5C1D_41BB_704D9F23A200_0/{face}/1/{row}_{column}.webp","colCount":12,"class":"TiledImageResourceLevel","tags":"ondemand","width":6144},{"height":512,"rowCount":1,"url":"media/panorama_406B0668_4D39_5C1D_41BB_704D9F23A200_0/{face}/2/{row}_{column}.webp","colCount":6,"class":"TiledImageResourceLevel","tags":["ondemand","preload"],"width":3072}]}}],"overlays":["this.overlay_5F79FC17_4D39_CC33_41CA_341324142692","this.overlay_5F5D0BA1_4D39_540F_41AF_3E38294A3AC6"],"hfov":360,"id":"panorama_406B0668_4D39_5C1D_41BB_704D9F23A200","class":"Panorama","hfovMax":130,"vfov":180,"data":{"label":"IMG_20250419_101926_00_merged"},"thumbnailUrl":"media/panorama_406B0668_4D39_5C1D_41BB_704D9F23A200_t.webp","label":trans('panorama_406B0668_4D39_5C1D_41BB_704D9F23A200.label'),"hfovMin":"135%"},{"adjacentPanoramas":[{"data":{"overlayID":"overlay_5F589BA2_4D39_540D_41CF_7C4D2BAFA730"},"panorama":"this.panorama_406B0668_4D39_5C1D_41BB_704D9F23A200","distance":26.24,"backwardYaw":115.63,"yaw":26.15,"class":"AdjacentPanorama","select":"this.overlay_5F589BA2_4D39_540D_41CF_7C4D2BAFA730.get('areas').forEach(function(a){ a.trigger('click') })"}],"frames":[{"class":"CubicPanoramaFrame","thumbnailUrl":"media/panorama_407FE2E8_4D39_741D_41B2_FCDF6042BAD4_t.webp","cube":{"class":"ImageResource","levels":[{"height":2048,"rowCount":4,"url":"media/panorama_407FE2E8_4D39_741D_41B2_FCDF6042BAD4_0/{face}/0/{row}_{column}.webp","colCount":24,"class":"TiledImageResourceLevel","tags":"ondemand","width":12288},{"height":1024,"rowCount":2,"url":"media/panorama_407FE2E8_4D39_741D_41B2_FCDF6042BAD4_0/{face}/1/{row}_{column}.webp","colCount":12,"class":"TiledImageResourceLevel","tags":"ondemand","width":6144},{"height":512,"rowCount":1,"url":"media/panorama_407FE2E8_4D39_741D_41B2_FCDF6042BAD4_0/{face}/2/{row}_{column}.webp","colCount":6,"class":"TiledImageResourceLevel","tags":["ondemand","preload"],"width":3072}]}}],"overlays":["this.overlay_5F589BA2_4D39_540D_41CF_7C4D2BAFA730"],"hfov":360,"id":"panorama_407FE2E8_4D39_741D_41B2_FCDF6042BAD4","class":"Panorama","hfovMax":130,"vfov":180,"data":{"label":"IMG_20250419_102045_00_merged"},"thumbnailUrl":"media/panorama_407FE2E8_4D39_741D_41B2_FCDF6042BAD4_t.webp","label":trans('panorama_407FE2E8_4D39_741D_41B2_FCDF6042BAD4.label'),"hfovMin":"135%"},{"initialPosition":{"pitch":0,"class":"PanoramaCameraPosition","yaw":0},"enterPointingToHorizon":true,"id":"panorama_407FE2E8_4D39_741D_41B2_FCDF6042BAD4_camera","class":"PanoramaCamera","initialSequence":"this.sequence_405B6CB7_4D39_4C73_41C9_BB6EC5F7F50C"},{"initialPosition":{"pitch":0,"class":"PanoramaCameraPosition","yaw":0},"enterPointingToHorizon":true,"id":"panorama_407F8EE4_4D39_4C15_41CF_296F297B32E6_camera","class":"PanoramaCamera","initialSequence":"this.sequence_405B4CB7_4D39_4C73_41CD_3BCE348A4DA6"},{"adjacentPanoramas":[{"data":{"overlayID":"overlay_5F224676_4D39_3CF5_41CA_108B78217F37"},"panorama":"this.panorama_434A5970_4D39_340D_41AB_0994DDE984F4","distance":44.17,"backwardYaw":30.34,"yaw":80.84,"class":"AdjacentPanorama","select":"this.overlay_5F224676_4D39_3CF5_41CA_108B78217F37.get('areas').forEach(function(a){ a.trigger('click') })"}],"frames":[{"class":"CubicPanoramaFrame","thumbnailUrl":"media/panorama_407F8EE4_4D39_4C15_41CF_296F297B32E6_t.webp","cube":{"class":"ImageResource","levels":[{"height":2048,"rowCount":4,"url":"media/panorama_407F8EE4_4D39_4C15_41CF_296F297B32E6_0/{face}/0/{row}_{column}.webp","colCount":24,"class":"TiledImageResourceLevel","tags":"ondemand","width":12288},{"height":1024,"rowCount":2,"url":"media/panorama_407F8EE4_4D39_4C15_41CF_296F297B32E6_0/{face}/1/{row}_{column}.webp","colCount":12,"class":"TiledImageResourceLevel","tags":"ondemand","width":6144},{"height":512,"rowCount":1,"url":"media/panorama_407F8EE4_4D39_4C15_41CF_296F297B32E6_0/{face}/2/{row}_{column}.webp","colCount":6,"class":"TiledImageResourceLevel","tags":["ondemand","preload"],"width":3072}]}}],"overlays":["this.overlay_5F224676_4D39_3CF5_41CA_108B78217F37"],"hfov":360,"id":"panorama_407F8EE4_4D39_4C15_41CF_296F297B32E6","class":"Panorama","hfovMax":130,"vfov":180,"data":{"label":"IMG_20250419_102224_00_merged"},"thumbnailUrl":"media/panorama_407F8EE4_4D39_4C15_41CF_296F297B32E6_t.webp","label":trans('panorama_407F8EE4_4D39_4C15_41CF_296F297B32E6.label'),"hfovMin":"135%"},{"id":"MainViewerPanoramaPlayer","aaEnabled":true,"touchControlMode":"drag_rotation","keepModel3DLoadedWithoutLocation":true,"mouseControlMode":"drag_rotation","displayPlaybackBar":true,"viewerArea":"this.MainViewer","class":"PanoramaPlayer","arrowKeysAction":"translate"},{"adjacentPanoramas":[{"data":{"overlayID":"overlay_5F03AC16_4D39_CC35_41D0_3204185A5582"},"panorama":"this.panorama_406B0668_4D39_5C1D_41BB_704D9F23A200","distance":22.8,"backwardYaw":51.81,"yaw":-30.64,"class":"AdjacentPanorama","select":"this.overlay_5F03AC16_4D39_CC35_41D0_3204185A5582.get('areas').forEach(function(a){ a.trigger('click') })"},{"data":{"overlayID":"overlay_5F13067C_4D39_3CF5_4198_58818598EEE1"},"panorama":"this.panorama_407F8EE4_4D39_4C15_41CF_296F297B32E6","distance":20.72,"backwardYaw":80.84,"yaw":30.34,"class":"AdjacentPanorama","select":"this.overlay_5F13067C_4D39_3CF5_4198_58818598EEE1.get('areas').forEach(function(a){ a.trigger('click') })"}],"frames":[{"class":"CubicPanoramaFrame","thumbnailUrl":"media/panorama_434A5970_4D39_340D_41AB_0994DDE984F4_t.webp","cube":{"class":"ImageResource","levels":[{"height":2048,"rowCount":4,"url":"media/panorama_434A5970_4D39_340D_41AB_0994DDE984F4_0/{face}/0/{row}_{column}.webp","colCount":24,"class":"TiledImageResourceLevel","tags":"ondemand","width":12288},{"height":1024,"rowCount":2,"url":"media/panorama_434A5970_4D39_340D_41AB_0994DDE984F4_0/{face}/1/{row}_{column}.webp","colCount":12,"class":"TiledImageResourceLevel","tags":"ondemand","width":6144},{"height":512,"rowCount":1,"url":"media/panorama_434A5970_4D39_340D_41AB_0994DDE984F4_0/{face}/2/{row}_{column}.webp","colCount":6,"class":"TiledImageResourceLevel","tags":["ondemand","preload"],"width":3072}]}}],"overlays":["this.overlay_5F13067C_4D39_3CF5_4198_58818598EEE1","this.overlay_5F03AC16_4D39_CC35_41D0_3204185A5582"],"hfov":360,"id":"panorama_434A5970_4D39_340D_41AB_0994DDE984F4","class":"Panorama","hfovMax":130,"vfov":180,"data":{"label":"IMG_20250419_101810_00_merged"},"thumbnailUrl":"media/panorama_434A5970_4D39_340D_41AB_0994DDE984F4_t.webp","label":trans('panorama_434A5970_4D39_340D_41AB_0994DDE984F4.label'),"hfovMin":"135%"},{"initialPosition":{"pitch":0,"class":"PanoramaCameraPosition","yaw":0},"enterPointingToHorizon":true,"id":"panorama_406B0668_4D39_5C1D_41BB_704D9F23A200_camera","class":"PanoramaCamera","initialSequence":"this.sequence_405B0CB7_4D39_4C73_41A4_35FBBF81F8D5"},{"id":"mainPlayList","class":"PlayList","items":[{"player":"this.MainViewerPanoramaPlayer","begin":"this.setEndToItemIndex(this.mainPlayList, 0, 1)","class":"PanoramaPlayListItem","camera":"this.panorama_407F8EE4_4D39_4C15_41CF_296F297B32E6_camera","media":"this.panorama_407F8EE4_4D39_4C15_41CF_296F297B32E6"},{"player":"this.MainViewerPanoramaPlayer","begin":"this.setEndToItemIndex(this.mainPlayList, 1, 2)","class":"PanoramaPlayListItem","camera":"this.panorama_434A5970_4D39_340D_41AB_0994DDE984F4_camera","media":"this.panorama_434A5970_4D39_340D_41AB_0994DDE984F4"},{"player":"this.MainViewerPanoramaPlayer","begin":"this.setEndToItemIndex(this.mainPlayList, 2, 3)","class":"PanoramaPlayListItem","camera":"this.panorama_406B0668_4D39_5C1D_41BB_704D9F23A200_camera","media":"this.panorama_406B0668_4D39_5C1D_41BB_704D9F23A200"},{"player":"this.MainViewerPanoramaPlayer","begin":"this.setEndToItemIndex(this.mainPlayList, 3, 0)","end":"this.trigger('tourEnded')","class":"PanoramaPlayListItem","camera":"this.panorama_407FE2E8_4D39_741D_41B2_FCDF6042BAD4_camera","media":"this.panorama_407FE2E8_4D39_741D_41B2_FCDF6042BAD4"}]},{"initialPosition":{"pitch":0,"class":"PanoramaCameraPosition","yaw":0},"enterPointingToHorizon":true,"id":"panorama_434A5970_4D39_340D_41AB_0994DDE984F4_camera","class":"PanoramaCamera","initialSequence":"this.sequence_4067FCB6_4D39_4C75_4195_F06919E4AE0F"},{"surfaceReticleSelectionColor":"#FFFFFF","subtitlesTextShadowColor":"#000000","playbackBarProgressBorderColor":"#000000","toolTipPaddingBottom":4,"progressBarBorderColor":"#000000","vrPointerSelectionColor":"#FF6600","subtitlesFontSize":"3vmin","toolTipPaddingTop":4,"toolTipFontSize":"1.11vmin","progressBarBackgroundColorRatios":[0],"playbackBarHeadBorderSize":0,"playbackBarHeadBackgroundColorRatios":[0,1],"playbackBarHeadBorderRadius":0,"subtitlesGap":0,"subtitlesTextShadowVerticalLength":1,"playbackBarHeadBorderColor":"#000000","playbackBarHeadShadow":true,"playbackBarBorderSize":0,"playbackBarHeadShadowColor":"#000000","vrPointerSelectionTime":2000,"subtitlesBackgroundColor":"#000000","toolTipPaddingRight":6,"playbackBarHeadBackgroundColor":["#111111","#666666"],"data":{"name":"Main Viewer"},"progressBarBackgroundColor":["#3399FF"],"toolTipShadowColor":"#333138","subtitlesTextShadowOpacity":1,"subtitlesBackgroundOpacity":0.2,"progressBackgroundColor":["#000000"],"progressBorderColor":"#000000","subtitlesBorderColor":"#FFFFFF","progressLeft":"33%","subtitlesTextShadowHorizontalLength":1,"toolTipPaddingLeft":6,"playbackBarBottom":5,"progressBottom":10,"toolTipFontColor":"#606060","progressHeight":2,"progressBorderSize":0,"firstTransitionDuration":0,"playbackBarBackgroundColor":["#FFFFFF"],"progressBarBorderRadius":2,"toolTipTextShadowColor":"#000000","playbackBarHeight":10,"toolTipFontFamily":"Arial","subtitlesFontColor":"#FFFFFF","playbackBarHeadWidth":6,"playbackBarProgressBorderSize":0,"id":"MainViewer","progressBarBorderSize":0,"playbackBarBackgroundColorDirection":"vertical","playbackBarRight":0,"subtitlesFontFamily":"Arial","toolTipBorderColor":"#767676","playbackBarProgressBorderRadius":0,"progressBackgroundColorRatios":[0],"surfaceReticleColor":"#FFFFFF","playbackBarHeadShadowBlurRadius":3,"playbackBarProgressBackgroundColor":["#3399FF"],"propagateClick":false,"progressRight":"33%","vrPointerColor":"#FFFFFF","class":"ViewerArea","progressBorderRadius":2,"subtitlesBottom":50,"minHeight":50,"playbackBarHeadShadowOpacity":0.7,"subtitlesTop":0,"minWidth":100,"toolTipBackgroundColor":"#F6F6F6","height":"100%","playbackBarProgressBackgroundColorRatios":[0],"width":"100%","playbackBarBackgroundOpacity":1,"progressOpacity":0.7,"playbackBarLeft":0,"progressBarBackgroundColorDirection":"horizontal","playbackBarHeadHeight":15,"playbackBarBorderRadius":0,"playbackBarBorderColor":"#FFFFFF"},{"id":"overlay_5F79FC17_4D39_CC33_41CA_341324142692","items":[{"pitch":-9.51,"distance":100,"yaw":51.81,"image":"this.AnimatedImageResource_5B581FC3_4D4B_4C13_41CF_F5A7074643B8","hfov":14.76,"vfov":15.12,"class":"HotspotPanoramaOverlayImage","data":{"label":"GoToImg_20250419_101810_00_merged"},"scaleMode":"fit_inside"}],"maps":[],"areas":["this.HotspotPanoramaOverlayArea_5E7CE1E3_4D38_F413_41D0_349EA929F39C"],"data":{"label":"GoToImg_20250419_101810_00_merged","hasPanoramaAction":true},"enabledInCardboard":true,"useHandCursor":true,"class":"HotspotPanoramaOverlay"},{"id":"overlay_5F5D0BA1_4D39_540F_41AF_3E38294A3AC6","items":[{"pitch":-10.56,"distance":100,"yaw":115.63,"image":"this.AnimatedImageResource_5B583FC3_4D4B_4C13_41D1_65B5BEFBF1C5","hfov":13.49,"vfov":18.37,"class":"HotspotPanoramaOverlayImage","data":{"label":"GoToImg_20250419_102045_00_merged"},"scaleMode":"fit_inside"}],"maps":[],"areas":["this.HotspotPanoramaOverlayArea_5FB0FBAE_4D39_5415_41D2_7A52AAB7BD78"],"data":{"label":"GoToImg_20250419_102045_00_merged","hasPanoramaAction":true},"enabledInCardboard":true,"useHandCursor":true,"class":"HotspotPanoramaOverlay"},{"id":"overlay_5F589BA2_4D39_540D_41CF_7C4D2BAFA730","items":[{"pitch":-3.7,"distance":100,"yaw":26.15,"image":"this.AnimatedImageResource_5B586FC3_4D4B_4C13_41C9_F215B56EAFE7","hfov":11.88,"vfov":13.28,"class":"HotspotPanoramaOverlayImage","data":{"label":"GoToImg_20250419_101926_00_merged"},"scaleMode":"fit_inside"}],"maps":[],"areas":["this.HotspotPanoramaOverlayArea_5FE28CA6_4D3B_4C15_41D2_44B87CDD1E18"],"data":{"label":"GoToImg_20250419_101926_00_merged","hasPanoramaAction":true},"enabledInCardboard":true,"useHandCursor":true,"class":"HotspotPanoramaOverlay"},{"movements":[{"class":"DistancePanoramaCameraMovement","yawSpeed":7.96,"easing":"cubic_in","yawDelta":18.5},{"class":"DistancePanoramaCameraMovement","yawSpeed":7.96,"yawDelta":323},{"class":"DistancePanoramaCameraMovement","yawSpeed":7.96,"easing":"cubic_out","yawDelta":18.5}],"id":"sequence_405B6CB7_4D39_4C73_41C9_BB6EC5F7F50C","class":"PanoramaCameraSequence"},{"movements":[{"class":"DistancePanoramaCameraMovement","yawSpeed":7.96,"easing":"cubic_in","yawDelta":18.5},{"class":"DistancePanoramaCameraMovement","yawSpeed":7.96,"yawDelta":323},{"class":"DistancePanoramaCameraMovement","yawSpeed":7.96,"easing":"cubic_out","yawDelta":18.5}],"id":"sequence_405B4CB7_4D39_4C73_41CD_3BCE348A4DA6","class":"PanoramaCameraSequence"},{"id":"overlay_5F224676_4D39_3CF5_41CA_108B78217F37","items":[{"pitch":-2.19,"distance":100,"yaw":80.84,"image":"this.AnimatedImageResource_5B5B4FC2_4D4B_4C0D_41CC_372F16775BA8","hfov":10.5,"vfov":10.5,"class":"HotspotPanoramaOverlayImage","data":{"label":"GoToImg_20250419_101810_00_merged"},"scaleMode":"fit_inside"}],"maps":[],"areas":["this.HotspotPanoramaOverlayArea_5FAFE6B1_4D39_3C0F_41C9_D610EB1359D3"],"data":{"label":"GoToImg_20250419_101810_00_merged","hasPanoramaAction":true},"enabledInCardboard":true,"useHandCursor":true,"class":"HotspotPanoramaOverlay"},{"id":"overlay_5F13067C_4D39_3CF5_4198_58818598EEE1","items":[{"pitch":-4.68,"distance":100,"yaw":30.34,"image":"this.AnimatedImageResource_5B5BBFC2_4D4B_4C0D_41C3_8EE99754C90F","hfov":10.5,"vfov":10.5,"class":"HotspotPanoramaOverlayImage","data":{"label":"GoToImg_20250419_102224_00_merged"},"scaleMode":"fit_inside"}],"maps":[],"areas":["this.HotspotPanoramaOverlayArea_5BA8965E_4D39_3C35_41CE_9BB38E4109F0"],"data":{"label":"GoToImg_20250419_102224_00_merged","hasPanoramaAction":true},"enabledInCardboard":true,"useHandCursor":true,"class":"HotspotPanoramaOverlay"},{"id":"overlay_5F03AC16_4D39_CC35_41D0_3204185A5582","items":[{"pitch":-4.25,"distance":100,"yaw":-30.64,"image":"this.AnimatedImageResource_5B5BDFC3_4D4B_4C13_41D1_1E1D44183FA0","hfov":10.5,"vfov":10.5,"class":"HotspotPanoramaOverlayImage","data":{"label":"GoToImg_20250419_101926_00_merged"},"scaleMode":"fit_inside"}],"maps":[],"areas":["this.HotspotPanoramaOverlayArea_5FA93C38_4D39_CC7D_419D_C0A3513CF804"],"data":{"label":"GoToImg_20250419_101926_00_merged","hasPanoramaAction":true},"enabledInCardboard":true,"useHandCursor":true,"class":"HotspotPanoramaOverlay"},{"movements":[{"class":"DistancePanoramaCameraMovement","yawSpeed":7.96,"easing":"cubic_in","yawDelta":18.5},{"class":"DistancePanoramaCameraMovement","yawSpeed":7.96,"yawDelta":323},{"class":"DistancePanoramaCameraMovement","yawSpeed":7.96,"easing":"cubic_out","yawDelta":18.5}],"id":"sequence_405B0CB7_4D39_4C73_41A4_35FBBF81F8D5","class":"PanoramaCameraSequence"},{"movements":[{"class":"DistancePanoramaCameraMovement","yawSpeed":7.96,"easing":"cubic_in","yawDelta":18.5},{"class":"DistancePanoramaCameraMovement","yawSpeed":7.96,"yawDelta":323},{"class":"DistancePanoramaCameraMovement","yawSpeed":7.96,"easing":"cubic_out","yawDelta":18.5}],"id":"sequence_4067FCB6_4D39_4C75_4195_F06919E4AE0F","class":"PanoramaCameraSequence"},{"levels":[{"height":200,"url":"media/res_58B3783F_4D3B_7473_41D0_E330A44CA4E1_0.webp","class":"ImageResourceLevel","width":4800}],"frameCount":24,"rowCount":1,"colCount":24,"id":"AnimatedImageResource_5B581FC3_4D4B_4C13_41CF_F5A7074643B8","class":"AnimatedImageResource","finalFrame":"first","frameDuration":41},{"displayTooltipInTouchScreens":true,"mapColor":"any","click":"this.setPlayListSelectedIndex(this.mainPlayList, 1)","id":"HotspotPanoramaOverlayArea_5E7CE1E3_4D38_F413_41D0_349EA929F39C","class":"HotspotPanoramaOverlayArea"},{"levels":[{"height":200,"url":"media/res_58B3783F_4D3B_7473_41D0_E330A44CA4E1_0.webp","class":"ImageResourceLevel","width":4800}],"frameCount":24,"rowCount":1,"colCount":24,"id":"AnimatedImageResource_5B583FC3_4D4B_4C13_41D1_65B5BEFBF1C5","class":"AnimatedImageResource","finalFrame":"first","frameDuration":41},{"displayTooltipInTouchScreens":true,"mapColor":"any","click":"this.setPlayListSelectedIndex(this.mainPlayList, 3)","id":"HotspotPanoramaOverlayArea_5FB0FBAE_4D39_5415_41D2_7A52AAB7BD78","class":"HotspotPanoramaOverlayArea"},{"levels":[{"height":200,"url":"media/res_58B3783F_4D3B_7473_41D0_E330A44CA4E1_0.webp","class":"ImageResourceLevel","width":4800}],"frameCount":24,"rowCount":1,"colCount":24,"id":"AnimatedImageResource_5B586FC3_4D4B_4C13_41C9_F215B56EAFE7","class":"AnimatedImageResource","finalFrame":"first","frameDuration":41},{"displayTooltipInTouchScreens":true,"mapColor":"any","click":"this.setPlayListSelectedIndex(this.mainPlayList, 2)","id":"HotspotPanoramaOverlayArea_5FE28CA6_4D3B_4C15_41D2_44B87CDD1E18","class":"HotspotPanoramaOverlayArea"},{"levels":[{"height":200,"url":"media/res_58B3783F_4D3B_7473_41D0_E330A44CA4E1_0.webp","class":"ImageResourceLevel","width":4800}],"frameCount":24,"rowCount":1,"colCount":24,"id":"AnimatedImageResource_5B5B4FC2_4D4B_4C0D_41CC_372F16775BA8","class":"AnimatedImageResource","finalFrame":"first","frameDuration":41},{"displayTooltipInTouchScreens":true,"mapColor":"any","click":"this.setPlayListSelectedIndex(this.mainPlayList, 1)","id":"HotspotPanoramaOverlayArea_5FAFE6B1_4D39_3C0F_41C9_D610EB1359D3","class":"HotspotPanoramaOverlayArea"},{"levels":[{"height":200,"url":"media/res_58B3783F_4D3B_7473_41D0_E330A44CA4E1_0.webp","class":"ImageResourceLevel","width":4800}],"frameCount":24,"rowCount":1,"colCount":24,"id":"AnimatedImageResource_5B5BBFC2_4D4B_4C0D_41C3_8EE99754C90F","class":"AnimatedImageResource","finalFrame":"first","frameDuration":41},{"displayTooltipInTouchScreens":true,"mapColor":"any","click":"this.setPlayListSelectedIndex(this.mainPlayList, 0)","id":"HotspotPanoramaOverlayArea_5BA8965E_4D39_3C35_41CE_9BB38E4109F0","class":"HotspotPanoramaOverlayArea"},{"levels":[{"height":200,"url":"media/res_58B3783F_4D3B_7473_41D0_E330A44CA4E1_0.webp","class":"ImageResourceLevel","width":4800}],"frameCount":24,"rowCount":1,"colCount":24,"id":"AnimatedImageResource_5B5BDFC3_4D4B_4C13_41D1_1E1D44183FA0","class":"AnimatedImageResource","finalFrame":"first","frameDuration":41},{"displayTooltipInTouchScreens":true,"mapColor":"any","click":"this.setPlayListSelectedIndex(this.mainPlayList, 2)","id":"HotspotPanoramaOverlayArea_5FA93C38_4D39_CC7D_419D_C0A3513CF804","class":"HotspotPanoramaOverlayArea"}],"width":"100%"};
if (script['data'] == undefined)
    script['data'] = {};
script['data']['translateObjs'] = translateObjs, script['data']['createQuizConfig'] = function () {
    var a = {};
    return this['get']('data')['translateObjs'] = translateObjs, a;
}, TDV['PlayerAPI']['defineScript'](script);
//# sourceMappingURL=script_device.js.map
})();
//Generated with v2025.0.7, Sat Apr 19 2025